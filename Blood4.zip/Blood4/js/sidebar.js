function openNav() {
	document.getElementById("mySidenav").style.width = "70%";
	document.body.style.backgroundColor = "#ffffff";
  }
  
  function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("main").style.marginLeft= "0";
	document.body.style.backgroundColor = "white";
  }